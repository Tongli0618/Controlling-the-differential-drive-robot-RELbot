from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='image_tools',
            executable='cam2image',
            name='cam2image',
            arguments=['--ros-args', '-p', 'depth:=1', '-p', 'history:=keep_last'],
        ),  
        Node(
            package='lpindicator',
            executable='lp_indicator_node',
            name='lp_indicator_node',
        )
    ])
