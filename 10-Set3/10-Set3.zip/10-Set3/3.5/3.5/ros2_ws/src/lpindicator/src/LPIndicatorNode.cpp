#include "lpindicator/LPIndicatorNode.hpp"

LPIndicatorNode::LPIndicatorNode() : Node("lp_indicator_node") {
    // Declare and get brightness threshold parameters
    this->declare_parameter<int>("r_min", 80);
    this->declare_parameter<int>("r_max", 180);
    this->declare_parameter<int>("g_min", 150);
    this->declare_parameter<int>("g_max", 255);
    this->declare_parameter<int>("b_min", 80);
    this->declare_parameter<int>("b_max", 200);
    this->get_parameter("r_min", r_min_);
    this->get_parameter("r_max", r_max_);
    this->get_parameter("g_min", g_min_);
    this->get_parameter("g_max", g_max_);
    this->get_parameter("b_min", b_min_);
    this->get_parameter("b_max", b_max_);

    // To allow updating the parameters while the node is running.
    auto parameter_callback =
        [this](const std::vector<rclcpp::Parameter> &parameters) -> rcl_interfaces::msg::SetParametersResult {
            rcl_interfaces::msg::SetParametersResult result;
            result.successful = true;
            for (const auto &parameter : parameters) {
                if (parameter.get_name() == "r_min") {
                    r_min_ = parameter.as_int();
                    RCLCPP_INFO(this->get_logger(), "Updated r_min to: %i", r_min_);
                }
                else if (parameter.get_name() == "r_max") {
                    r_max_ = parameter.as_int();
                    RCLCPP_INFO(this->get_logger(), "Updated r_max to: %i", r_max_);
                }
                else if (parameter.get_name() == "g_min") {
                    g_min_ = parameter.as_int();
                    RCLCPP_INFO(this->get_logger(), "Updated g_min to: %i", g_min_);
                }
                else if (parameter.get_name() == "g_max") {
                    g_max_ = parameter.as_int();
                    RCLCPP_INFO(this->get_logger(), "Updated g_max to: %i", g_max_);
                }
                else if (parameter.get_name() == "b_min") {
                    b_min_ = parameter.as_int();
                    RCLCPP_INFO(this->get_logger(), "Updated b_min to: %i", b_min_);
                }
                else if (parameter.get_name() == "b_max") {
                    b_max_ = parameter.as_int();
                    RCLCPP_INFO(this->get_logger(), "Updated b_max to: %i", b_max_);
                }
            }
            return result;
        };
    param_callback_handle_ = this->add_on_set_parameters_callback(parameter_callback);

    // Subscribe to image topic
    image_subscription_ = this->create_subscription<sensor_msgs::msg::Image>(
        "image", 10, std::bind(&LPIndicatorNode::image_callback, this, std::placeholders::_1));

    // Publisher for the position of the detected light
    positiondata_publisher_ = this->create_publisher<geometry_msgs::msg::Point>("light_position",1);
    // Publisher for processed image
    processed_image_publisher_ = this->create_publisher<sensor_msgs::msg::Image>("processed_image_topic", 10);
}

void LPIndicatorNode::image_callback(const sensor_msgs::msg::Image::SharedPtr msg) {
    // Convert the ROS image to cv
    cv_bridge::CvImagePtr cv_image = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    
    // Extract the color channels
    std::vector<cv::Mat> channels(3);
    cv::split(cv_image->image, channels);
    
    // Apply thresholds to find the desired color
    cv::Mat r_min_mask, r_max_mask, r_mask;
    cv::threshold(channels[2], r_min_mask, r_min_, 255, cv::THRESH_BINARY);
    cv::threshold(channels[2], r_max_mask, r_max_, 255, cv::THRESH_BINARY_INV);
    cv::bitwise_and(r_min_mask, r_max_mask, r_mask);
    
    cv::Mat g_min_mask, g_max_mask, g_mask;
    cv::threshold(channels[1], g_min_mask, g_min_, 255, cv::THRESH_BINARY);
    cv::threshold(channels[1], g_max_mask, g_max_, 255, cv::THRESH_BINARY_INV);
    cv::bitwise_and(g_min_mask, g_max_mask, g_mask);
    
    cv::Mat b_min_mask, b_max_mask, b_mask;
    cv::threshold(channels[0], b_min_mask, b_min_, 255, cv::THRESH_BINARY);
    cv::threshold(channels[0], b_max_mask, b_max_, 255, cv::THRESH_BINARY_INV);
    cv::bitwise_and(b_min_mask, b_max_mask, b_mask);
    
    // Combine masks
    cv::Mat binary_image;
    cv::bitwise_and(r_mask, g_mask, binary_image);
    cv::bitwise_and(binary_image, b_mask, binary_image);

    // Close small voids
    const int dilation_size = 2;
    const int dilation_iterations = 1;

    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(2 * dilation_size + 1, 2 * dilation_size + 1), cv::Point(dilation_size, dilation_size));
    cv::Mat dilated;
    cv::erode(binary_image, dilated, kernel, cv::Point(-1, -1), dilation_iterations);

    // Remove small areas
    const int erosion_size = 2;
    const int erosion_iterations = 3;

    kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(2 * erosion_size + 1, 2 * erosion_size + 1), cv::Point(erosion_size, erosion_size));
    cv::Mat eroded;
    cv::erode(dilated, eroded, kernel, cv::Point(-1, -1), erosion_iterations);

    // Compute the center of gravity of the white pixels
    cv::Point2d center = compute_center_of_gravity(eroded);

    // New Draw a circle at the center point in the binary image
    cv::Mat colored_image;
    cv::cvtColor(eroded, colored_image, cv::COLOR_GRAY2BGR);
    cv::circle(colored_image, center, 10, CV_RGB(0,0,255), 2);

    // New Convert the processed image back to a ROS message
    std_msgs::msg::Header header;
    header.stamp = this->get_clock()->now();
    cv_bridge::CvImage cv_image_processed(header, "bgr8", colored_image);
    sensor_msgs::msg::Image ros_image_processed;
    cv_image_processed.toImageMsg(ros_image_processed);

    // Publish the position
    geometry_msgs::msg::Point position_data_message;
    position_data_message.x = center.x;
    position_data_message.y = center.y;  
    position_data_message.z = 0.0; 
    positiondata_publisher_->publish(position_data_message);

    // Publish processed image
    processed_image_publisher_->publish(ros_image_processed);
}

cv::Point2d LPIndicatorNode::compute_center_of_gravity(const cv::Mat& image) {
    cv::Moments m = cv::moments(image, true);
    return cv::Point2d(m.m10 / m.m00, m.m01 / m.m00);
}

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LPIndicatorNode>());
    rclcpp::shutdown();
    return 0;
}
