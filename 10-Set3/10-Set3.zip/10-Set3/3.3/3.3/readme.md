# Compiling
1. Navigate into the `xenomai4-framework` folder
2. Build the packages.

    ```
    colcon build --symlink-install
    ```
3. Source the packages.

    ```
    source install/setup.bash
    ```
4. Navigate into the `xenomai4-framework/src/xeno_thread` folder
5. Create a folder called build.

    ```
    mkdir build
    ```
6. Go into the build folder and build.

    ```
    cd build
    cmake ..
    make
    ```
7. Navigate into the `ros2_ws` folder.
8. Build the packages.

    ```
    colcon build --symlink-install
    ```


# Running
Open 3 terminals and follow the instructions below.

## Terminal 1
1. Navigate into the `xenomai4-framework/src/xenothread/build` folder.
2. Run the xenomai thread.

    ```
    sudo ./xenoThread
    ```

## Terminal 2
1. Navigate into the `xenomai4-framework` folder
2. Source the workspace

    ```
    source install/setup.bash
    ```
3. Run the RosXenoBridge

    ```
    ./RosXenoBridge.bash
    ```

## Terminal 3
1. Navigate into the `ros2_ws` folder
2. Source the workspace

    ```
    source install/setup.bash
    ```
3. Launch the vel2conv and converter node.

    ```
    ros2 launch set_vel2conv vel2conv.launch.py
    ```