#include "MyApp.h"


MyApp::MyApp() 
{
    printf("%s: Constructing rampio\n", __FUNCTION__);
}

MyApp::~MyApp()
{
    printf("%s: Destructing rampio\n", __FUNCTION__);
}

int MyApp::preProc()
{
    return 0;
}


int MyApp::postProc()
{
    // Directly map RosData to pwm output
    FpgaOutput.pwm1 = RosData.x; 
    FpgaOutput.pwm2 = RosData.y; 

    return 0;
}