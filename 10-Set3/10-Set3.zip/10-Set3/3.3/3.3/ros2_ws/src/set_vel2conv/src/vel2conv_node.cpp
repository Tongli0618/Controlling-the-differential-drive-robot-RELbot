#include "set_vel2conv/vel2conv_node.hpp"

using namespace std::chrono_literals;

Vel2conNode::Vel2conNode() : Node("vel2conv_node") {
    left_motor_publisher_ = this->create_publisher<std_msgs::msg::Float64>("left_motor_setpoint_vel", 10);
    right_motor_publisher_ = this->create_publisher<std_msgs::msg::Float64>("right_motor_setpoint_vel", 10);
    timer_ = this->create_wall_timer(1000ms, std::bind(&Vel2conNode::publishMotorVelocities, this));
}

void Vel2conNode::publishMotorVelocities() {
    std_msgs::msg::Float64 left_msg;
    std_msgs::msg::Float64 right_msg;

    left_msg.data = 512;
    right_msg.data = 512;

    left_motor_publisher_->publish(left_msg);
    right_motor_publisher_->publish(right_msg);
}

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<Vel2conNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
