from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='set_vel2conv',
            executable='vel2conv_node',
            name='vel2conv_node'
        ),
        Node(
            package='converter',
            executable='converter_node',
            name='converter_node',
        )
    ])
