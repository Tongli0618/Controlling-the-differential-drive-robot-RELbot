#ifndef CONVERTER_NODE_HPP
#define CONVERTER_NODE_HPP

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"
#include "custom_msgs/msg/ros2_xeno.hpp"

class ConverterNode : public rclcpp::Node {
public:
    ConverterNode();

private:
    void publishMotorVelocities();

    rclcpp::Publisher<custom_msgs::msg::Ros2Xeno>::SharedPtr motor_vel_pub_;
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr left_motor_sub_;
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr right_motor_sub_;

    double current_left_motor_vel_;
    double current_right_motor_vel_;
};

#endif  // CONVERTER_NODE_HPP
