#include "converter/converter_node.hpp"

ConverterNode::ConverterNode() : Node("converter_node") {
    motor_vel_pub_ = this->create_publisher<custom_msgs::msg::Ros2Xeno>("Ros2Xeno", 10);

    left_motor_sub_ = this->create_subscription<std_msgs::msg::Float64>(
        "left_motor_setpoint_vel", 10, 
        [this](const std_msgs::msg::Float64::SharedPtr msg) {
            current_left_motor_vel_ = msg->data;
            publishMotorVelocities();
        });

    right_motor_sub_ = this->create_subscription<std_msgs::msg::Float64>(
        "right_motor_setpoint_vel", 10, 
        [this](const std_msgs::msg::Float64::SharedPtr msg) {
            current_right_motor_vel_ = msg->data;
            publishMotorVelocities();
        });
}

void ConverterNode::publishMotorVelocities() {
    custom_msgs::msg::Ros2Xeno motor_vel_msg;
    motor_vel_msg.x = current_left_motor_vel_;
    motor_vel_msg.y = current_right_motor_vel_;
    motor_vel_pub_->publish(motor_vel_msg);
    RCLCPP_INFO(this->get_logger(), "Publishing motor velocities: Left = %f, Right = %f", 
                motor_vel_msg.x, motor_vel_msg.y);
}

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<ConverterNode>());
    rclcpp::shutdown();
    return 0;
}
