# Compiling
1. Navigate into the `ros2_ws` folder.
2. Build the packages.

    ```
    colcon build --symlink-install
    ```


# Running
Open 2 terminals and follow the instructions below.

## Terminal 1
1. Navigate into the `ros2_ws` folder.
2. Source the workspace
    ```
    source install/setup.bash
    ```
3. Launch the light point indicator launch file.
    ```
    ros2 launch lpindicator lpindicator.launch.py
    ```
4. If needed the following parameters can be adjusted to adjust rgb ranges used to detect the cube:

    ```
    r_min
    r_max
    g_min
    g_max
    b_min
    b_max
    ```
    For example:
    ```
    ros2 param set lp_indicator_node r_min 80
    ```

## Terminal 2
1. Navigate into the `ros2_ws/src/closed_loop/install/sequence_controller/lib/sequence_controller/` folder
2. Make the sequence controller executable

    ```
    sudo chmod +x sequence_controller
    ```
3. Run the sequence controller

    ```
    ./sequence_controller
    ```