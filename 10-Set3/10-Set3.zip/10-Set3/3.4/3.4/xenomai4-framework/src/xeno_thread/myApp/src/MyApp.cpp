#include "MyApp.h"


MyApp::MyApp() 
{
    printf("%s: Constructing rampio\n", __FUNCTION__);

    prevPosLeft = 0;
    prevPosRight = 0;
}

MyApp::~MyApp()
{
    printf("%s: Destructing rampio\n", __FUNCTION__);
}

// Function to calculate the encoder difference and correct for over/under flow
int MyApp::posDiff(const int &input, int &previous) {
    int posDiff = input - previous;

    if (posDiff > 8191)         // Underflow correction
        posDiff -= 16384;
    else if (posDiff < -8191)   // Overflow correction
        posDiff += 16384;
    
    previous = input;

    return posDiff;
}

int MyApp::preProc()
{
    const int diffPosLeft = posDiff(FpgaInput.channel2, prevPosLeft);
    const int diffPosRight = posDiff(FpgaInput.channel1, prevPosRight);
    
    u[0] += diffPosLeft / 1024.0 / 15.58 / 4.0 * 2.0 * 3.14159;     // PosLeft
    u[1] -= diffPosRight / 1024.0 / 15.58 / 4.0 * 2.0 * 3.14159;    // PosRight
    u[2] = RosData.x;                                               // SetVelLeft
    u[3] = RosData.y;                                               // SetVelRight

    return 0;
}


int MyApp::postProc()
{
   
    FpgaOutput.pwm2 = y[0];  // Left motor
    FpgaOutput.pwm1 = -y[1];  // Right motor

    return 0;
}