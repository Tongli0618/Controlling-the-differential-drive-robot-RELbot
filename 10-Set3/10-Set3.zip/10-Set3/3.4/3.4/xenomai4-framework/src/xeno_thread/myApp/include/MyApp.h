#pragma once

#include "Native20Sim.h"

class MyApp : public Native20Sim
{
public:
    MyApp();
    ~MyApp();
    
private:
    int posDiff(const int &pulses, int &previous);

    int prevPosLeft, prevPosRight;
protected:
    int preProc() override;
    int postProc() override;
};
