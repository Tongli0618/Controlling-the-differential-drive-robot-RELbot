#ifndef VEL2CONV_NODE_HPP
#define VEL2CONV_NODE_HPP

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

class Vel2conNode : public rclcpp::Node {
public:
    Vel2conNode();

private:
    void publishMotorVelocities();
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr left_motor_publisher_;
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr right_motor_publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    int count_;
};

#endif // VELOCITY_NODE_HPP
