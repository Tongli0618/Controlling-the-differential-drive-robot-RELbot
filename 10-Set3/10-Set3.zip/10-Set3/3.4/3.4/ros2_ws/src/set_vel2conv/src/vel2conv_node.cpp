#include "set_vel2conv/vel2conv_node.hpp"

using namespace std::chrono_literals;

Vel2conNode::Vel2conNode() : Node("vel2conv_node") {
    count_ = 0;     // To keep track of current time step

    left_motor_publisher_ = this->create_publisher<std_msgs::msg::Float64>("left_motor_setpoint_vel", 10);
    right_motor_publisher_ = this->create_publisher<std_msgs::msg::Float64>("right_motor_setpoint_vel", 10);
    timer_ = this->create_wall_timer(1000ms, std::bind(&Vel2conNode::publishMotorVelocities, this));
}

void Vel2conNode::publishMotorVelocities() {
    std_msgs::msg::Float64 left_msg;
    std_msgs::msg::Float64 right_msg;

    // Four one second time steps
    switch (count_ % 4) {
        case 0:
            // Drive forward
            left_msg.data = 1.57;
            right_msg.data = 1.57;
            break;
        case 1:
            // Drive forward
            left_msg.data = 1.57;
            right_msg.data = 1.57;
            break;
        case 2:
            // Turn right
            left_msg.data = 1.57;
            right_msg.data = -1.57;
            break;
        case 3:
            // Turn right
            left_msg.data= 1.57;
            right_msg.data = -1.57;
            break;
    }
    
    left_motor_publisher_->publish(left_msg);
    right_motor_publisher_->publish(right_msg);
    count_++;
}

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<Vel2conNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
